﻿/*
 * CRC16CCITT_Implementation.cs
 * Copyright 2015 ISAC
 * All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person or organization 
 * obtaining a copy of this software to use, reproduce, display, distribute, 
 * execute, and transmit the software, and to prepare derivative works of the 
 * software, and to permit third-parties to whom the software is furnished to do so.
 * 
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT
 * SHALL THE AUTHORS, DEVELOPERS, COPYRIGHT HOLDERS OR ANYONE DISTRIBUTING THIS 
 * SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
 * OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF OR IN CONNECTION WITH THIS SOFTWARE OR
 * THE USE OR OTHER DEALING IN THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 */
namespace CRC16CCITT {
    /// <summary>
    /// CRC Algorithm class that computes the polynomial x^16 + x^12 + x^5 + 1 as per FCS3.0 Standard,
    /// also known as CRC-CCITT or Kermit protocol
    /// </summary>
    /// <author>Michael Goldberg @ BD</author> 
    public class CRC16CCITT_Implementation
    {

        /// <summary>
        /// The initial CRC remainder as specified by the CRC-CCITT (Kermit) protocol. 
        /// </summary>
        public const ushort InitialCrcRemainder = 0x0;

        /// <summary>
        /// The generator polynomial defined for the CRC-CCITT (Kermit) algorithm.
        /// </summary>
        /// <remarks>
        ///  The polynomial x16 + x12 + x5 + 1 is represented as
        ///  1 0001 0000 0010 0001
        ///  The high order bit (x^16) is always on, so don't need to store it (it is implied by the algorithm).  
        ///  => 0001 0000 0010 0001 
        /// Invert the order because this implementation works on the bits in reverse order (LSB to MSB)
        ///  => 1000 0100 0000 1000 => 0x8408
        /// </remarks>
        private const int KermitGeneratorPolynomial = 0x8408;

        /// <summary>
        /// The size of the precalculated byte CRC table (256 possible values for an 8 bit byte);
        /// </summary>
        private const int ByteTableSize = 256;

        /// <summary>
        /// Precalculated table of byte CRC's
        /// </summary>
        static readonly ushort[] ByteCrcTable = new ushort[ByteTableSize];

        static CRC16CCITT_Implementation() {
            // Fill the ByteCrcTable with pre-calculated values.  

            // Pseudocode:
            // For each byte in ByteCrcTable
            //   initialize the CRC
            //   For each bit in the byte (from LSB to MSB)
            //      If the LSB is set after XORing with the interim CRC
            //         CRC = CRC/2  ^ GeneratorPolynomial
            //      else
            //         CRC = CRC/2
            //      byte = byte/2
            //   end for
            //   ByteCrcTable[byteIndex] = CRC.
            // end for

            for (int i = 0; i < ByteTableSize; ++i) {

                ushort crc = InitialCrcRemainder;
                ushort data = (ushort)i;

                for (int j = 0; j < 8; ++j) {
                    if (((crc ^ data) & 0x0001) != 0) {
                        crc = (ushort)((crc >> 1) ^ KermitGeneratorPolynomial);
                    }
                    else {
                        crc >>= 1;
                    }
                    data >>= 1;
                }

                ByteCrcTable[i] = crc;
            }
        }
        /// <summary>
        /// Computes the CRC for the given byte array
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns>the computed CRC value as an unsigned short</returns>
        public static ushort ComputeCrc(byte[] bytes)
        {
            return ComputeCrc(InitialCrcRemainder, bytes, 0, bytes.LongLength);
        }

        /// <summary>
        /// Computes the checkSum for the given byte array with offset and count based on initial crc.
        /// </summary>
        /// <param name="initial">The initial value of crc</param>
        /// <param name="bytes">byte array to compute crc of</param>
        /// <param name="offset">the offset at which to start computing</param>
        /// <param name="count">the number of bytes to compute</param>
        /// <returns>the computed CRC value as an unsigned short</returns>
        /// <remarks>Used for iterating over a byte stream so doesn't have to be all loaded into memory at once.</remarks>
        public static ushort ComputeCrc(ushort initial, byte[] bytes, long offset, long count) {
            ushort crc = initial;
            long end = offset + count;
            // Divide the message by the polynomial, a byte at a time.
            for (long j = offset; j < end; ++j) {
                byte data = (byte)((crc & 0xff) ^ bytes[j]);
                crc = (ushort)(ByteCrcTable[data] ^ (crc >> 8));
            }
            return crc;
        }
    }
}
